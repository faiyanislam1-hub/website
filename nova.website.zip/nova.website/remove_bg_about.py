from PIL import Image

def remove_background():
    input_path = "About_Me.png"
    output_path = "About_Me_Transparent.png"
    
    try:
        img = Image.open(input_path).convert("RGBA")
        datas = img.getdata()
        
        newData = []
        for item in datas:
            # Change white pixels to transparent
            # Using a slightly higher threshold to catch near-whites in the photo background
            if item[0] > 230 and item[1] > 230 and item[2] > 230:
                newData.append((255, 255, 255, 0))
            else:
                newData.append(item)
        
        img.putdata(newData)
        img.save(output_path, "PNG")
        print(f"Successfully saved {output_path}")
        
    except Exception as e:
        print(f"Error processing image: {e}")

if __name__ == "__main__":
    remove_background()
